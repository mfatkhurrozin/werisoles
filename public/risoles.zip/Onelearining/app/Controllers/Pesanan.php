<?php

namespace App\Controllers;

use App\Models\PesananModel;
use App\Models\ProdukModel;

class Pesanan extends BaseController
{
    public function __construct()
    {
        $this->PesananModel = new PesananModel();
        $this->ProdukModel = new ProdukModel();
    }


    public function index()
    {
        $currentPage = $this->request->getVar('page_tugas') ? $this->request->getVar('page_tugas') : 1;

        $keyword = $this->request->getVar('keyword');
        if ($keyword) {
            $tugas = $this->PesananModel->search($keyword);
        } else {
            $tugas = $this->PesananModel;
        }
        $data = [
            'title' => 'Daftar Tugas',
            'pesanusr' => $this->PesananModel->getPesananusr(user_id()),
            'pesanan'  => $this->PesananModel->paginate(4, 'pesanan'),
            'pager' => $this->PesananModel->pager,
            'currentPage' => $currentPage
        ];

        return view('produk/pesanan/index', $data);
    }

    // public function getData()
    // {
    //     $pesan = new PesananModel();
    //     $dataPesan = $pesan->find(2);
    // }

    public function detail($id)
    {
        $data = [
            'title' => 'Detail tugas',
            'pesanan' => $this->PesananModel->getPesanan($id)
        ];

        // jika data tugas tidak di temukan
        if (empty($data['pesanan'])) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Judul tugas' . $id . 'Tidak Ditemukan');
        }

        return view('produk/pesanan/detail', $data);
    }

    public function tambah($id)
    {
        //mengambil data input saat melakukan validasi
        session();
        $data = [
            'title' => 'Tambah Data Tugas',
            'validation' => \Config\Services::validation(),
            'id_produk' => $this->ProdukModel->find($id),
            'user' => $this->PesananModel->getPesanan($id)
        ];


        return view('produk/pesanan/tambah', $data);
    }


    public function simpan()
    {
        //validasi input data
        if (!$this->validate([
            'jumlah' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib di isi'
                ]
            ],
            'nama' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib di isi'
                ]
            ],
            'alamat' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib di isi'
                ]
            ],
            'file' => [
                'rules' => 'uploaded[file]',
                'errors' => [
                    'uploaded' => 'Pilihlah file bukti pembayaran',

                ]
            ]
        ])) {

            // menampilkan pesan kesalahan
            // $validation = \Config\Services::validation();
            session()->setFlashdata('error', $this->validator->listErrors());
            // return redirect()->to('/produk/pesanan/tambah')->withInput()->with('validation', $validation);
            // return redirect()->to('/tugasjawab/tambah')->withInput();
            return redirect()->back()->withInput();
        }


        //mengambil gambar sampul
        $fileSampul = $this->request->getFile('file');

        //generate nama sampul random
        $namaSampul = $fileSampul->getRandomName();

        //meminddahkan file sampul ke folder img
        $fileSampul->move('jwb', $namaSampul);

        $this->PesananModel->save([
            'nama' => $this->request->getVar('nama'),
            'nama_menu' => $this->request->getVar('nama_produk'),
            'alamat' => $this->request->getVar('alamat'),
            'hp' => $this->request->getVar('hp'),
            'jumlah' => $this->request->getVar('jumlah'),
            'total' => $this->request->getVar('total'),
            'tanggal' => $this->request->getVar('tanggal'),
            'file' => $namaSampul,
            'id_menu' => $this->request->getVar('id_produk'),
            'id_user' => $this->request->getVar('id_user')
        ]);

        //flashdata pesan disimpan
        session()->setFlashdata('pesan', 'Tugas Berhasil Dikirim');

        return redirect()->to('/pesanan');
    }
}
