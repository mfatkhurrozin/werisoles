<?php

namespace App\Controllers;

use App\Models\PesananModel;
use App\Models\ProdukModel;

class Pesananadm extends BaseController
{
    public function __construct()
    {
        $this->PesananModel = new PesananModel();
        $this->ProdukModel = new ProdukModel();
    }

    public function index()
    {
        $currentPage = $this->request->getVar('page_tugas') ? $this->request->getVar('page_tugas') : 1;

        $keyword = $this->request->getVar('keyword');
        if ($keyword) {
            $tugas = $this->PesananModel->search($keyword);
        } else {
            $tugas = $this->PesananModel;
        }
        $data = [
            'title' => 'Daftar Tugas',
            // 'tugas' => $this->PesananModel->getTugas()
            'pesanan'  => $this->PesananModel->paginate(4, 'pesanan'),
            'pager' => $this->PesananModel->pager,
            'currentPage' => $currentPage
        ];

        return view('pemilik/pesananadm/index', $data);
    }

    public function detail($id)
    {
        $data = [
            'title' => 'Detail tugas',
            'pesananadm' => $this->PesananModel->getPesananadm($id)
        ];

        // jika data tugas tidak di temukan
        if (empty($data['pesananadm'])) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Judul tugas' . $id . 'Tidak Ditemukan');
        }

        return view('pemilik/pesananadm/detail', $data);
    }

    public function hapus($id)
    {
        //cari gambar berdasarkan id
        $pesanan = $this->PesananModel->find($id);

        //cek gambar default (tidak boleh dihapus)
        if ($pesanan['file'] != 'default.jpg') {

            //hapus gambar di folder mtr
            unlink('jwb/' . $pesanan['file']);
        }

        $this->PesananModel->delete($id);

        //flashdata pesan dihapus
        session()->setFlashdata('pesan', 'Data Anda Sudah Hilang!');

        return redirect()->to('/pesananadm');
    }
}
