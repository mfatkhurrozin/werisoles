<?= $this->extend('/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class= "col">
            <h1>Muhammad Fatkhurrozin </h1>
            <P><?=$tentang ?></p>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>